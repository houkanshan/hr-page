(function() {
    
    $('#teams li p').css('display','none');

    $('#teams').on('click', 'li', function() {
    	var $this = $(this);
    	if ($this.children('p').is(':hidden')){
    		$this
    		.children('p')
	    		.slideDown(500)
	    	.end()
	    	.siblings().children('p')
	    		.slideUp(500)
	    } else {
	    	$this.children('p').slideUp(500);
	    }
	});

	$('.itm').on('mouseenter', 'img.wb', function(){
		$(this).css('opacity', 0);
		$(this).prev().css('opacity', 1);
	}).on('mouseleave', 'img.wb', function(){
		$(this).css('opacity', 1);
		$(this).prev().css('opacity', 0);
	});

})();